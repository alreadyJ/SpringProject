CREATE VIEW user_except_serial AS
  SELECT
    `split`.`user`.`email`         AS `email`,
    `split`.`user`.`password`      AS `password`,
    `split`.`user`.`nick_name`     AS `nick_name`,
    `split`.`user`.`phone`         AS `phone`,
    `split`.`user`.`profile_image` AS `profile_image`,
    `split`.`user`.`sign_up_date`  AS `sign_up_date`,
    `split`.`user`.`address`       AS `address`,
    `split`.`user`.`country`       AS `country`,
    `split`.`user`.`description`   AS `description`
  FROM `split`.`user`;
